Cryo Engine is a native 3D game engine with a visual editor, scripted in the Cryo language.

## Download

| System | File |
|---|---|
| Windows 10/11 (64-bit) | `CryoEngine-v0.3.0-beta-windows-x86_64.zip` |
| macOS 11+ (Apple Silicon and Intel) | `CryoEngine-v0.3.0-beta-macos-universal.zip` |
| Linux (x86_64) | `CryoEngine-v0.3.0-beta-linux-x86_64.zip` |

Unzip and run. On first launch the editor creates the example game in `~/CryoProjects/FrostpeakIsles` and starts a welcome tour.

**macOS:** the app is not signed. Right-click **Cryo Engine.app** and choose **Open** the first time. If macOS still refuses, run `xattr -dr com.apple.quarantine "Cryo Engine.app"` in a terminal.

## New in 0.3.0-beta

- **Timeline**: animation clips with keyframes for position, rotation, scale, colour and field of view, with Smooth, Linear and Step easing, and a preview in the editor.
- **Events in sync**: sounds, script events, camera cuts and screen text placed at exact instants of a clip.
- **Cutscenes**: clips that block input and show cinema bars; Enter skips them without losing their events.
- **Real-time animation from scripts**: `anim.play`, `anim.stop`, `anim.playing`, `on animation_end(name)` and `scene.set_camera`.
- **Timers**: `after(seconds, "event")`, `every(seconds, "event")` and `cancel("event")`.
- **Modelling**: Edit Mesh mode with face and vertex selection, move/rotate/scale, extrude, inset, subdivide, flip, fill, merge and delete, saved as `.obj`.
- The example game opens with a cutscene and plays an animation when the last Frost Shard is found.
- Two new tutorials: animation and modelling.

An existing `FrostpeakIsles` project is not overwritten: to see the new example, choose File > Open or create project and pick an empty folder.

## From 0.2.1-beta

English interface with Portuguese as a second language, built-in tutorials, the Frostpeak Isles platformer, the documentation site, contact normals in `on collide`.

## Known limits

No skeletal animation, no rotational physics, shadows from one directional light, and export only for the system you are running on. Script error messages are in English only.
