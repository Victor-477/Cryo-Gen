# ❄ Cryo Engine

[![CI](https://github.com/Victor-477/Cryo-Gen/actions/workflows/ci.yml/badge.svg)](https://github.com/Victor-477/Cryo-Gen/actions/workflows/ci.yml)
[![Release](https://img.shields.io/github/v/release/Victor-477/Cryo-Gen?include_prereleases&label=download)](https://github.com/Victor-477/Cryo-Gen/releases)
[![License: GPL v3](https://img.shields.io/badge/license-GPLv3-blue.svg)](LICENSE)

A native 3D game engine (Rust + OpenGL) with a Unity/Unreal-style visual editor. Games are scripted in **Cryo**, a small, safe language made for the engine.

![The Cryo Engine editor](docs/img/editor.png)

**[Documentation](https://victor-477.github.io/Cryo-Gen/)** · **[Download](https://github.com/Victor-477/Cryo-Gen/releases)** · [Run from source](#run-from-source) · [The Cryo language](#the-cryo-language) · [Example game](#example-game-frostpeak-isles)

## Download

Pre-built editors for Windows, macOS and Linux are on the [Releases page](https://github.com/Victor-477/Cryo-Gen/releases). Unzip and run; no installation and no source code needed.

On first launch the editor creates the example project in `~/CryoProjects/FrostpeakIsles` and starts a short welcome tour.

> **macOS:** the app is not signed. The first time, right-click **Cryo Engine.app** and choose **Open**.

## Run from source

Requires [Rust](https://rustup.rs). On Linux, also install `libasound2-dev` (audio).

```bash
git clone https://github.com/Victor-477/Cryo-Gen.git
cd Cryo-Gen
cargo run --release
```

Other ways to start:

```bash
cargo run --release -- path/to/MyGame   # open (or create) a project in that folder
cargo run --release -- --play           # start in Play mode
cargo run --release -- MyGame --game    # run only the game, without the editor
cargo test                              # language, physics, import and example-game tests
```

If you get a graphics configuration error, run with `CRYO_MSAA=0`.

## What is in the box

| | |
|---|---|
| **Editor** | Dockable panels (Hierarchy, Scene, Game, Inspector, Content, Console, script editor), move/rotate/scale gizmos, undo/redo, parent/child entities, Play/Pause/Stop. |
| **Rendering** | Primitives and imported models (`.obj`, `.gltf`, `.glb`), textures, directional/point/spot lights, shadows, sky gradient. |
| **Physics** | Gravity, oriented box and sphere colliders, triggers, contact events with normals. |
| **Scripting** | The Cryo language, with live error checking and script properties editable in the Inspector. |
| **Animation** | Timeline with keyframes, real-time clips started from scripts, cutscenes with camera cuts, and events fired at exact instants. Timers in scripts (`after`, `every`). |
| **Modelling** | Edit Mesh mode: select faces or vertices, move, extrude, inset, subdivide, merge, fill; saved as `.obj`. |
| **Audio** | Sound effects and looping music (`.wav`, `.ogg`, `.mp3`). |
| **Camera tools** | Fly, orbit, pan, zoom, trackpad gestures, orthographic axis views, framing, bookmarks. |
| **Export** | One menu item produces a standalone game for the system you are on. |
| **Tutorials** | Ten guided tours inside the editor (Help > Tutorials, or F1). |
| **Languages** | English interface, with Portuguese as a second language (🌐 menu, top right). |

## The Cryo language

Each `.cryo` file defines one `script`, attached to an entity in the Inspector.

```cryo
script Coin {
    prop spin: num = 160            // editable in the Inspector

    on update(dt) {                 // every frame
        self.rotate(vec3(0, spin * dt, 0))
    }

    on collide(other, normal) {     // on contact
        if other.name == "Player" {
            other.send("coin")      // runs `on coin()` in the player's script
            audio.play("sounds/coin.wav")
            self.destroy()
        }
    }
}
```

- **Types:** `num`, `bool`, `text`, `vec3`, `entity`, `list`, `any`. Annotations are optional and checked when present.
- **Safe by default:** `let` is immutable, conditions must be `bool`, and division by zero, out-of-range indexes, `nil` access and runaway loops become clear errors with a line number. A broken script is disabled; the editor keeps running.

The full reference (syntax, built-in functions and the engine API) is in the [documentation](https://victor-477.github.io/Cryo-Gen/#language).

## Example game: Frostpeak Isles

A small 3D platformer that ships as the default project, built only with editor primitives and twelve short Cryo scripts. It opens with a cutscene made in the Timeline.

![Frostpeak Isles](docs/img/game.png)

| Move | Keys |
|---|---|
| Run / jump | `WASD` / `Space` |
| Triple jump | three jumps in a row while running |
| Backflip / long jump | `Shift` + `Space` standing still / while running |
| Ground pound | `Shift` in the air |
| Wall jump | jump against a wall, then `Space` |
| Throw the cap | `F` or click; hold to keep it hovering, then jump onto it to bounce |
| Capture | hit a Hopper with the cap to control it; `E` leaves |
| Camera | arrow keys or right-drag, wheel zooms |

Collect the five Frost Shards. Every mechanic is covered by an automated play-through test in `crates/cryo-editor/src/runtime.rs`.

## Repository layout

```
crates/
  cryo-lang/       the Cryo language: lexer, parser, interpreter (no dependencies)
  cryo-editor/
    src/scene.rs     entities, components, .cryoscene (JSON) serialisation
    src/assets.rs    model (.obj, .gltf, .glb) and texture import
    src/render.rs    OpenGL renderer: meshes, textures, lights, shadows, sky, grid
    src/physics.rs   gravity and collisions (oriented boxes and spheres)
    src/audio.rs     sound effects and music
    src/anim.rs      animation clips: tracks, keys, timed events
    src/timeline.rs  Timeline panel
    src/mesh_edit.rs editable polygon mesh and modelling operations
    src/meshmode.rs  Edit Mesh mode in the Scene
    src/runtime.rs   Play mode: connects Cryo scripts to the scene
    src/viewport.rs  Scene and Game tabs, editor camera, gizmos, picking
    src/panels.rs    Hierarchy, Inspector, Content, Console, script editor
    src/tutorial.rs  built-in guided tours
    src/i18n.rs      interface languages
    src/project.rs   project on disk, example game, import and export
    src/app.rs       editor state, menus, toolbar, layout
    template/        scripts of the example game
docs/              documentation site (GitHub Pages)
```

## Known limits (0.3.0-beta)

- Animation: position, rotation, scale, colour and field of view. No skeletal animation yet.
- Modelling: `.obj` models, one material, automatic texture coordinates. No loop cuts, bevels or booleans yet.
- Models: mesh, base colour and base texture. glTF animations, skeletons and full PBR materials are not read yet.
- Shadows: first directional light only, covering about 50 m around the camera.
- Lights: up to 4 directional and 16 point/spot lights per scene.
- Physics: no rotational dynamics (bodies do not tip over). A model's collider is its bounding box, not its mesh.
- Export targets the system the editor is running on. The macOS app is not signed.
- Script error messages are in English only.

## License

Distributed under the [GNU GPL v3](LICENSE).
