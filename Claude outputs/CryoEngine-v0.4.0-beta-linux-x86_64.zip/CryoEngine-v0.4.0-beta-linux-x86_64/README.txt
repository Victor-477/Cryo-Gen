Cryo Engine 0.4.0-beta

Run the editor:
  Windows  double-click cryo.exe
  macOS    right-click "Cryo Engine.app" and choose Open (the app is not signed)
  Linux    ./cryo

On first launch the editor creates the example game in
~/CryoProjects/FrostpeakIsles and starts a short welcome tour.

Documentation: https://victor-477.github.io/Cryo-Gen/
Source code:   https://github.com/Victor-477/Cryo-Gen
