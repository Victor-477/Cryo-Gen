Cryo Engine is a native 3D game engine with a visual editor, scripted in the Cryo language.

## Download

| System | File |
|---|---|
| Windows 10/11 (64-bit) | `CryoEngine-v0.5.0-beta-windows-x86_64.zip` |
| macOS 11+ (Apple Silicon and Intel) | `CryoEngine-v0.5.0-beta-macos-universal.zip` |
| Linux (x86_64) | `CryoEngine-v0.5.0-beta-linux-x86_64.zip` |

Unzip and run. On first launch the editor creates the example game in `~/CryoProjects/FrostpeakIsles` and starts a welcome tour.

**macOS:** the app is not signed. Right-click **Cryo Engine.app** and choose **Open** the first time. If macOS still refuses, run `xattr -dr com.apple.quarantine "Cryo Engine.app"` in a terminal.

## New in 0.5.0-beta

- **Ashen Keep**, a second example game: a medieval hack and slash with one complete level (outer bailey, courtyard, great hall), a knight with combos, heavy blows, rolls and blocks, three kinds of enemies, gates that open as areas are cleared, checkpoints, and a boss finished with a quick time event. File > New example: Ashen Keep.
- Every model and texture of the game is generated from code by `tools/make_ashen_assets.py`: rigged characters with their animation clips, castle pieces, props.
- **HUD**: `bar(name, value, colour)` draws meters (health, stamina, boss) and `banner(text, seconds)` a large message.
- **Fog**: a scene setting; distant objects fade into the horizon colour.
- `animate(clip, speed, false)` plays a skeletal clip once and holds its last pose.

## From 0.4.0-beta

Quick time events, global events and tags, maps, `match` and state machines in the language, the first-person player, skeletal animation, mesh colliders, bodies that rotate, export for another system.

## Known limits

Skeletal animation runs on the CPU, mesh colliders are for static bodies, shadows come from one directional light, and there are no loop cuts or bevels in the modeller yet. Script error messages are in English only.
