#!/usr/bin/env python3
"""Builds every model and texture of the "Ashen Keep" example game from code.

    python3 tools/make_ashen_assets.py

Output goes to crates/cryo-editor/template/ashen/ and is embedded in the editor.
Characters are rigged glTF files (skeleton + animation clips); scenery is OBJ with
tiling textures. Nothing here comes from an external asset: change the numbers and run again.
"""
import base64, json, math, os, struct
import numpy as np
from PIL import Image

OUT = os.path.join(os.path.dirname(__file__), "..", "crates", "cryo-editor", "template", "ashen")
os.makedirs(OUT, exist_ok=True)

# ------------------------------------------------------------------ small math
def rot(rx, ry, rz):
    """Rotation matrix for Euler angles in degrees, applied as Ry * Rx * Rz."""
    x, y, z = (math.radians(a) for a in (rx, ry, rz))
    mx = np.array([[1, 0, 0], [0, math.cos(x), -math.sin(x)], [0, math.sin(x), math.cos(x)]])
    my = np.array([[math.cos(y), 0, math.sin(y)], [0, 1, 0], [-math.sin(y), 0, math.cos(y)]])
    mz = np.array([[math.cos(z), -math.sin(z), 0], [math.sin(z), math.cos(z), 0], [0, 0, 1]])
    return my @ mx @ mz

def quat(rx, ry, rz):
    m = rot(rx, ry, rz)
    t = m[0, 0] + m[1, 1] + m[2, 2]
    if t > 0:
        s = math.sqrt(t + 1) * 2
        q = [(m[2, 1] - m[1, 2]) / s, (m[0, 2] - m[2, 0]) / s, (m[1, 0] - m[0, 1]) / s, s / 4]
    elif m[0, 0] > m[1, 1] and m[0, 0] > m[2, 2]:
        s = math.sqrt(1 + m[0, 0] - m[1, 1] - m[2, 2]) * 2
        q = [s / 4, (m[0, 1] + m[1, 0]) / s, (m[0, 2] + m[2, 0]) / s, (m[2, 1] - m[1, 2]) / s]
    elif m[1, 1] > m[2, 2]:
        s = math.sqrt(1 + m[1, 1] - m[0, 0] - m[2, 2]) * 2
        q = [(m[0, 1] + m[1, 0]) / s, s / 4, (m[1, 2] + m[2, 1]) / s, (m[0, 2] - m[2, 0]) / s]
    else:
        s = math.sqrt(1 + m[2, 2] - m[0, 0] - m[1, 1]) * 2
        q = [(m[0, 2] + m[2, 0]) / s, (m[1, 2] + m[2, 1]) / s, s / 4, (m[1, 0] - m[0, 1]) / s]
    n = math.sqrt(sum(c * c for c in q))
    return [c / n for c in q]

# ------------------------------------------------------------------ mesh builder
class Mesh:
    """Triangles grouped by material; every vertex may follow one joint."""
    def __init__(self):
        self.tris = {}  # material -> list of (position, normal, joint)

    def tri(self, mat, pts, normals, joint):
        self.tris.setdefault(mat, []).extend((np.array(p, float), np.array(n, float), joint) for p, n in zip(pts, normals))

    def quad(self, mat, a, b, c, d, n, joint):
        ns = n if isinstance(n, list) else [n] * 4
        self.tri(mat, [a, b, c], [ns[0], ns[1], ns[2]], joint)
        self.tri(mat, [a, c, d], [ns[0], ns[2], ns[3]], joint)

    def box(self, mat, center, size, joint=0, r=None):
        c = np.array(center, float)
        h = np.array(size, float) / 2
        m = rot(*r) if r else np.eye(3)
        corner = lambda sx, sy, sz: c + m @ (h * np.array([sx, sy, sz]))
        faces = [((1, 0, 0), [(1, -1, -1), (1, 1, -1), (1, 1, 1), (1, -1, 1)]),
                 ((-1, 0, 0), [(-1, -1, 1), (-1, 1, 1), (-1, 1, -1), (-1, -1, -1)]),
                 ((0, 1, 0), [(-1, 1, -1), (-1, 1, 1), (1, 1, 1), (1, 1, -1)]),
                 ((0, -1, 0), [(-1, -1, 1), (-1, -1, -1), (1, -1, -1), (1, -1, 1)]),
                 ((0, 0, 1), [(1, -1, 1), (1, 1, 1), (-1, 1, 1), (-1, -1, 1)]),
                 ((0, 0, -1), [(-1, -1, -1), (-1, 1, -1), (1, 1, -1), (1, -1, -1)])]
        for n, cs in faces:
            self.quad(mat, *[corner(*s) for s in cs], m @ np.array(n, float), joint)

    def lathe(self, mat, profile, center=(0, 0), sides=10, sx=1.0, sz=1.0, joint=0, flat=False, r=None, pivot=None):
        """Profile is a list of (y, radius) from bottom to top, spun around a vertical axis."""
        cx, cz = center
        m = rot(*r) if r else np.eye(3)
        pv = np.array(pivot if pivot else (cx, profile[0][0], cz), float)
        place = lambda p: pv + m @ (np.array(p, float) - pv)
        def point(i, k):
            y, rad = profile[i]
            a = k / sides * math.tau
            return (cx + math.cos(a) * rad * sx, y, cz + math.sin(a) * rad * sz)
        def normal(i, k):
            j0, j1 = max(i - 1, 0), min(i + 1, len(profile) - 1)
            dy, dr = profile[j1][0] - profile[j0][0], profile[j1][1] - profile[j0][1]
            a = k / sides * math.tau
            n = np.array([math.cos(a) * dy / sx, -dr, math.sin(a) * dy / sz])
            l = np.linalg.norm(n)
            return m @ (n / l if l > 1e-9 else np.array([0, 1.0, 0]))
        for i in range(len(profile) - 1):
            for k in range(sides):
                a, b, c, d = point(i, k), point(i + 1, k), point(i + 1, k + 1), point(i, k + 1)
                if flat:
                    fn = np.cross(np.array(b) - a, np.array(d) - a)
                    fn = m @ (fn / (np.linalg.norm(fn) or 1))
                    ns = [fn] * 4
                else:
                    ns = [normal(i, k), normal(i + 1, k), normal(i + 1, k + 1), normal(i, k + 1)]
                self.quad(mat, place(a), place(b), place(c), place(d), ns, joint)
        for i, up in ((0, -1.0), (len(profile) - 1, 1.0)):
            if profile[i][1] > 1e-6:
                mid = (cx, profile[i][0], cz)
                n = m @ np.array([0, up, 0])
                for k in range(sides):
                    a, b = point(i, k), point(i, k + 1)
                    self.tri(mat, [place(mid), place(b if up > 0 else a), place(a if up > 0 else b)], [n] * 3, joint)

def ball(y, r, n=5, squash=1.0):
    return [(y + math.cos(math.pi * (1 - i / n)) * r * squash, max(math.sin(math.pi * i / n) * r, 0.0)) for i in range(n + 1)]

# ------------------------------------------------------------------ OBJ output (scenery)
def write_obj(name, mesh, materials, tile=2.0):
    """`materials`: name -> (rgb, texture file or None). Texture coordinates repeat every `tile` metres."""
    lines, vi = [f"# Ashen Keep: {name} (generated by tools/make_ashen_assets.py)", f"mtllib {name}.mtl"], 1
    for mat, verts in mesh.tris.items():
        lines.append(f"usemtl {mat}")
        for i in range(0, len(verts), 3):
            face = []
            for p, n, _ in verts[i:i + 3]:
                axis = int(np.argmax(np.abs(n)))
                u, v = [(p[2], p[1]), (p[0], p[2]), (p[0], p[1])][axis]
                lines.append(f"v {p[0]:.4f} {p[1]:.4f} {p[2]:.4f}")
                lines.append(f"vt {u / tile:.4f} {v / tile:.4f}")
                lines.append(f"vn {n[0]:.3f} {n[1]:.3f} {n[2]:.3f}")
                face.append(f"{vi}/{vi}/{vi}")
                vi += 1
            lines.append("f " + " ".join(face))
    open(os.path.join(OUT, name + ".obj"), "w").write("\n".join(lines) + "\n")
    mtl = []
    for mat in mesh.tris:
        rgb, tex = materials[mat]
        mtl += [f"newmtl {mat}", f"Kd {rgb[0]} {rgb[1]} {rgb[2]}"] + ([f"map_Kd {tex}"] if tex else [])
    open(os.path.join(OUT, name + ".mtl"), "w").write("\n".join(mtl) + "\n")

# ------------------------------------------------------------------ glTF output (characters)
def write_gltf(name, mesh, colors, joints, clips):
    """`joints`: list of (name, parent index or None, position). `clips`: name -> (duration, tracks),
    where tracks maps a joint index to [(time, (rx, ry, rz))] and "move" to [(time, (x, y, z))] for the root."""
    bin_, views, accessors = bytearray(), [], []
    def add(data, fmt, kind, count, ctype, extra=None):
        while len(bin_) % 4:
            bin_.append(0)
        raw = struct.pack("<%d%s" % (len(data), fmt), *data)
        views.append({"buffer": 0, "byteOffset": len(bin_), "byteLength": len(raw)})
        bin_.extend(raw)
        acc = {"bufferView": len(views) - 1, "componentType": ctype, "count": count, "type": kind}
        acc.update(extra or {})
        accessors.append(acc)
        return len(accessors) - 1
    prims, mats = [], []
    for mat, verts in mesh.tris.items():
        pos = [c for p, _, _ in verts for c in p]
        nor = [c for _, n, _ in verts for c in n]
        jnt = [c for _, _, j in verts for c in (j, 0, 0, 0)]
        wgt = [c for _ in verts for c in (1.0, 0.0, 0.0, 0.0)]
        P = np.array(pos).reshape(-1, 3)
        prims.append({"attributes": {
            "POSITION": add(pos, "f", "VEC3", len(verts), 5126, {"min": P.min(0).tolist(), "max": P.max(0).tolist()}),
            "NORMAL": add(nor, "f", "VEC3", len(verts), 5126),
            "JOINTS_0": add(jnt, "H", "VEC4", len(verts), 5123),
            "WEIGHTS_0": add(wgt, "f", "VEC4", len(verts), 5126)}, "material": len(mats)})
        mats.append({"name": mat, "pbrMetallicRoughness": {"baseColorFactor": list(colors[mat]) + [1.0]}})
    ibm = []
    for _, _, p in joints:
        ibm += [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, -p[0], -p[1], -p[2], 1]
    ibm_acc = add(ibm, "f", "MAT4", len(joints), 5126)
    nodes = [{"name": name, "mesh": 0, "skin": 0}]
    for i, (jn, parent, p) in enumerate(joints):
        base = joints[parent][2] if parent is not None else (0, 0, 0)
        node = {"name": jn, "translation": [p[0] - base[0], p[1] - base[1], p[2] - base[2]]}
        kids = [k + 1 for k, j in enumerate(joints) if j[1] == i]
        if kids:
            node["children"] = kids
        nodes.append(node)
    animations = []
    for clip, (duration, tracks) in clips.items():
        samplers, channels = [], []
        # every joint gets a key at 0 and at the end, so clips blend cleanly
        for j in range(len(joints)):
            keys = sorted(tracks.get(j, [(0, (0, 0, 0))]))
            if keys[0][0] > 0:
                keys.insert(0, (0, keys[0][1]))
            if keys[-1][0] < duration:
                keys.append((duration, keys[-1][1]))
            t = add([k[0] for k in keys], "f", "SCALAR", len(keys), 5126, {"min": [0], "max": [duration]})
            v = add([c for k in keys for c in quat(*k[1])], "f", "VEC4", len(keys), 5126)
            samplers.append({"input": t, "output": v, "interpolation": "LINEAR"})
            channels.append({"sampler": len(samplers) - 1, "target": {"node": j + 1, "path": "rotation"}})
        move = sorted(tracks.get("move", [(0, (0, 0, 0))]))
        if move[-1][0] < duration:
            move.append((duration, move[-1][1]))
        root = joints[0][2]
        t = add([k[0] for k in move], "f", "SCALAR", len(move), 5126, {"min": [0], "max": [duration]})
        v = add([root[i] + k[1][i] for k in move for i in range(3)], "f", "VEC3", len(move), 5126)
        samplers.append({"input": t, "output": v, "interpolation": "LINEAR"})
        channels.append({"sampler": len(samplers) - 1, "target": {"node": 1, "path": "translation"}})
        animations.append({"name": clip, "samplers": samplers, "channels": channels})
    doc = {"asset": {"version": "2.0", "generator": "Cryo Engine (make_ashen_assets.py)"}, "scene": 0,
           "scenes": [{"nodes": [0, 1]}], "nodes": nodes, "meshes": [{"primitives": prims}], "materials": mats,
           "skins": [{"joints": list(range(1, len(joints) + 1)), "inverseBindMatrices": ibm_acc}],
           "animations": animations, "accessors": accessors, "bufferViews": views,
           "buffers": [{"byteLength": len(bin_), "uri": "data:application/octet-stream;base64," + base64.b64encode(bytes(bin_)).decode()}]}
    json.dump(doc, open(os.path.join(OUT, name + ".gltf"), "w"), separators=(",", ":"))

# ------------------------------------------------------------------ characters
# Joints. The character faces -Z (the engine's "forward"); +X is its right.
HIPS, CHEST, HEAD, ARM_L, FORE_L, ARM_R, FORE_R, LEG_L, SHIN_L, LEG_R, SHIN_R = range(11)
JOINTS = [("Hips", None, (0, 0.95, 0)), ("Chest", HIPS, (0, 1.12, 0)), ("Head", CHEST, (0, 1.5, 0)),
          ("ArmL", CHEST, (-0.27, 1.42, 0)), ("ForeL", ARM_L, (-0.27, 1.14, 0)),
          ("ArmR", CHEST, (0.27, 1.42, 0)), ("ForeR", ARM_R, (0.27, 1.14, 0)),
          ("LegL", HIPS, (-0.11, 0.92, 0)), ("ShinL", LEG_L, (-0.11, 0.5, 0)),
          ("LegR", HIPS, (0.11, 0.92, 0)), ("ShinR", LEG_R, (0.11, 0.5, 0))]

def humanoid(style):
    m = Mesh()
    bone = style in ("skeleton", "archer", "brute")
    k = 0.55 if bone else 1.0          # limb thickness
    main = "bone" if bone else "steel"
    trim = "rust" if bone else "gold"
    # torso
    if bone:
        m.lathe(main, [(0.9, 0.035), (1.46, 0.035)], sides=6, joint=CHEST)            # spine
        for y in (1.1, 1.19, 1.28, 1.37):
            m.lathe(main, [(y - 0.02, 0.15), (y, 0.17), (y + 0.02, 0.15)], sides=10, sx=1.1, sz=0.75, joint=CHEST)
        m.lathe(main, [(0.86, 0.1), (0.94, 0.15), (1.0, 0.1)], sx=1.15, sz=0.7, joint=HIPS)  # pelvis
        if style == "brute":
            m.lathe("dark", [(1.0, 0.17), (1.2, 0.21), (1.42, 0.2), (1.47, 0.1)], sx=1.15, sz=0.82, joint=CHEST)
            m.lathe("rust", ball(1.45, 0.12), center=(-0.3, 0), joint=CHEST)
            m.lathe("rust", ball(1.45, 0.12), center=(0.3, 0), joint=CHEST)
    else:
        m.lathe(main, [(0.86, 0.13), (0.94, 0.17), (1.02, 0.16)], sx=1.1, sz=0.8, joint=HIPS)
        m.lathe("leather", [(0.98, 0.17), (1.03, 0.17)], sx=1.12, sz=0.82, joint=HIPS)   # belt
        m.lathe(main, [(1.0, 0.15), (1.12, 0.19), (1.3, 0.22), (1.42, 0.2), (1.48, 0.1)], sx=1.15, sz=0.8, joint=CHEST)
        m.box("cloth", (0, 1.22, -0.172), (0.2, 0.3, 0.012), CHEST)                      # tabard, chest
        m.box(trim, (0, 1.24, -0.18), (0.07, 0.11, 0.012), CHEST)                         # emblem
        m.box("cloth", (0, 0.76, -0.14), (0.24, 0.42, 0.015), HIPS)                       # tabard, skirt
        m.box("cloth", (0, 0.76, 0.14), (0.24, 0.42, 0.015), HIPS)
        for x in (-0.3, 0.3):
            m.lathe(main, ball(1.44, 0.115, squash=0.8), center=(x, 0), joint=ARM_L if x < 0 else ARM_R)  # pauldrons
            m.lathe(trim, [(1.395, 0.118), (1.41, 0.118)], center=(x, 0), joint=ARM_L if x < 0 else ARM_R)
    # head
    if bone:
        m.lathe(main, ball(1.63, 0.105), sz=1.1, joint=HEAD)
        m.box(main, (0, 1.535, -0.03), (0.12, 0.05, 0.12), HEAD)                          # jaw
        for x in (-0.04, 0.04):
            m.box("black", (x, 1.63, -0.105), (0.04, 0.04, 0.03), HEAD)                   # eye sockets
        m.box("black", (0, 1.585, -0.108), (0.02, 0.03, 0.02), HEAD)
        if style == "brute":
            m.lathe("dark", [(1.66, 0.115), (1.72, 0.1), (1.76, 0.0)], joint=HEAD)        # iron cap
            for x in (-0.11, 0.11):
                m.lathe(main, [(1.68, 0.03), (1.86, 0.0)], center=(x, 0), sides=6, joint=HEAD, r=(0, 0, -30 if x > 0 else 30))
    else:
        m.lathe(main, [(1.48, 0.08), (1.52, 0.115), (1.64, 0.125), (1.72, 0.11), (1.78, 0.06), (1.8, 0.0)], joint=HEAD)
        m.box("black", (0, 1.645, -0.118), (0.16, 0.022, 0.03), HEAD)                     # visor slit
        m.box(main, (0, 1.6, -0.125), (0.025, 0.14, 0.02), HEAD)                          # nose guard
        if style == "boss":
            for a in range(0, 360, 60):                                                   # crown of spikes
                x, z = math.cos(math.radians(a)) * 0.1, math.sin(math.radians(a)) * 0.1
                m.lathe(trim, [(1.72, 0.022), (1.9, 0.0)], center=(x, z), sides=5, joint=HEAD)
        else:
            m.box("cloth", (0, 1.85, 0.03), (0.028, 0.12, 0.2), HEAD)                     # plume
    # arms and legs
    for side, arm, fore, leg, shin in ((-1, ARM_L, FORE_L, LEG_L, SHIN_L), (1, ARM_R, FORE_R, LEG_R, SHIN_R)):
        ax, lx = 0.27 * side, 0.11 * side
        m.lathe(main, [(1.14, 0.05 * k), (1.3, 0.06 * k), (1.42, 0.055 * k)], center=(ax, 0), sides=8, joint=arm)
        m.lathe(main, [(0.9, 0.045 * k), (1.0, 0.055 * k), (1.14, 0.05 * k)], center=(ax, 0), sides=8, joint=fore)
        m.box("bone" if bone else "leather", (ax, 0.85, 0), (0.075 * (0.8 if bone else 1), 0.1, 0.075), fore)  # hand
        m.lathe(main, [(0.5, 0.06 * k), (0.72, 0.08 * k), (0.92, 0.085 * k)], center=(lx, 0), sides=8, joint=leg)
        m.lathe(main, [(0.1, 0.05 * k), (0.3, 0.065 * k), (0.5, 0.06 * k)], center=(lx, 0), sides=8, joint=shin)
        if not bone:
            m.lathe(trim, ball(0.5, 0.068), center=(lx, -0.02), sides=8, joint=shin)      # knee
        m.box("bone" if bone else "dark", (lx, 0.05, -0.04), (0.1 * (0.8 if bone else 1), 0.1, 0.24), shin)    # foot
    # weapons: held in the right hand, pointing forward (-Z)
    hx, hy = 0.27, 0.85
    if style == "archer":
        for dy, rx in ((0.32, 22), (0.0, 0), (-0.32, -22)):                               # bow, left hand
            m.box("wood", (-0.27, hy + dy, -0.1 + abs(dy) * 0.3), (0.025, 0.34, 0.03), FORE_L, r=(rx, 0, 0))
        m.box("black", (-0.27, hy, 0.02), (0.006, 0.95, 0.006), FORE_L)
    else:
        long, wide = {"knight": (0.95, 0.055), "boss": (1.55, 0.085), "brute": (0.75, 0.05)}.get(style, (0.85, 0.05))
        blade = "steel_bright" if not bone else "rust"
        m.box("leather", (hx, hy, -0.03), (0.03, 0.03, 0.2), FORE_R)                      # grip
        m.lathe(trim, ball(hy, 0.03), center=(hx, 0.09), sides=6, joint=FORE_R)           # pommel
        if style == "brute":
            m.box("wood", (hx, hy, -0.5), (0.035, 0.035, 0.8), FORE_R)                    # axe haft
            m.box(blade, (hx, hy + 0.14, -0.82), (0.02, 0.42, 0.2), FORE_R)
            m.box(blade, (hx, hy + 0.3, -0.82), (0.02, 0.12, 0.32), FORE_R)
        else:
            m.box(trim, (hx, hy, -0.14), (0.24 if style != "boss" else 0.36, 0.03, 0.035), FORE_R)   # guard
            m.box(blade, (hx, hy, -0.15 - long / 2), (wide, 0.012, long), FORE_R)
            m.box(blade, (hx, hy, -0.15 - long - 0.04), (wide * 0.55, 0.012, 0.09), FORE_R)          # tip
    if style == "knight":                                                                # shield, left arm
        m.lathe("cloth", [(0.98, 0.0), (0.985, 0.25), (1.015, 0.27), (1.02, 0.0)], center=(-0.345, -0.03), sides=12,
                sx=1.15, sz=0.85, joint=FORE_L, r=(0, 0, 90), pivot=(-0.345, 1.0, -0.03))
        m.lathe("steel", [(0.99, 0.27), (1.01, 0.29), (1.02, 0.27)], center=(-0.345, -0.03), sides=12,
                sx=1.15, sz=0.85, joint=FORE_L, r=(0, 0, 90), pivot=(-0.345, 1.0, -0.03))
        m.lathe(trim, ball(1.0, 0.06, squash=0.6), center=(-0.38, -0.03), sides=8, joint=FORE_L, r=(0, 0, 90), pivot=(-0.38, 1.0, -0.03))
    if style == "boss":                                                                  # cape
        m.box("cloth", (0, 1.0, 0.2), (0.5, 0.9, 0.02), CHEST, r=(8, 0, 0))
        m.box("cloth", (0, 1.43, 0.15), (0.56, 0.06, 0.1), CHEST)
    return m

def clips_for(style):
    I, R = (0, 0, 0), None
    c = {}
    # standing: the sword arm slightly raised, a slow breath
    guard = {ARM_R: [(0, (25, 0, 8))], FORE_R: [(0, (35, 0, 0))], ARM_L: [(0, (10, 0, -8))], FORE_L: [(0, (30, 0, 0))]}
    c["Idle"] = (2.0, {**guard, CHEST: [(0, (-2, 0, 0)), (1.0, (2, 0, 0)), (2.0, (-2, 0, 0))],
                       HEAD: [(0, (0, -4, 0)), (1.0, (0, 4, 0)), (2.0, (0, -4, 0))],
                       "move": [(0, (0, 0, 0)), (1.0, (0, -0.015, 0)), (2.0, (0, 0, 0))]})
    def gait(d, swing, lean, bob):
        q = d / 4
        return (d, {HIPS: [(0, (-lean, 0, 0))], CHEST: [(0, (-lean * 0.6, 8, 0)), (2 * q, (-lean * 0.6, -8, 0)), (d, (-lean * 0.6, 8, 0))],
                    LEG_L: [(0, (swing, 0, 0)), (2 * q, (-swing * 0.8, 0, 0)), (d, (swing, 0, 0))],
                    LEG_R: [(0, (-swing * 0.8, 0, 0)), (2 * q, (swing, 0, 0)), (d, (-swing * 0.8, 0, 0))],
                    SHIN_L: [(0, (-10, 0, 0)), (q, (-swing * 1.3, 0, 0)), (2 * q, (-25, 0, 0)), (3 * q, (-5, 0, 0)), (d, (-10, 0, 0))],
                    SHIN_R: [(0, (-25, 0, 0)), (q, (-5, 0, 0)), (2 * q, (-10, 0, 0)), (3 * q, (-swing * 1.3, 0, 0)), (d, (-25, 0, 0))],
                    ARM_L: [(0, (-swing * 0.6, 0, -8)), (2 * q, (swing * 0.6, 0, -8)), (d, (-swing * 0.6, 0, -8))],
                    FORE_L: [(0, (45, 0, 0))],
                    ARM_R: [(0, (30, 0, 8)), (2 * q, (15, 0, 8)), (d, (30, 0, 8))], FORE_R: [(0, (40, 0, 0))],
                    "move": [(0, (0, 0, 0)), (q, (0, bob, 0)), (2 * q, (0, 0, 0)), (3 * q, (0, bob, 0)), (d, (0, 0, 0))]})
    c["Run"] = gait(0.56, 42, 12, 0.05)
    c["Walk"] = gait(0.95, 24, 5, 0.025)
    def swing(d, wind, hit, chest_w, chest_h, rest=guard):
        """One cut: wind up, strike at 40% of the clip, recover."""
        a, b = d * 0.28, d * 0.45
        return (d, {ARM_R: [(0, rest[ARM_R][0][1]), (a, wind), (b, hit), (d, rest[ARM_R][0][1])],
                    FORE_R: [(0, (35, 0, 0)), (a, (70, 0, 0)), (b, (5, 0, 0)), (d, (35, 0, 0))],
                    CHEST: [(0, I), (a, chest_w), (b, chest_h), (d, I)],
                    ARM_L: [(0, (10, 0, -8)), (a, (-15, 0, -25)), (b, (25, 0, -12)), (d, (10, 0, -8))], FORE_L: [(0, (30, 0, 0))],
                    LEG_L: [(0, I), (b, (22, 0, 0)), (d, I)], LEG_R: [(0, I), (b, (-18, 0, 0)), (d, I)],
                    SHIN_R: [(0, I), (b, (-20, 0, 0)), (d, I)],
                    "move": [(0, (0, 0, 0)), (b, (0, -0.05, 0)), (d, (0, 0, 0))]})
    c["Attack1"] = swing(0.5, (120, -50, 30), (20, 60, 10), (0, -30, 0), (-12, 35, 0))      # right to left
    c["Attack2"] = swing(0.5, (60, 70, 10), (40, -70, 40), (0, 30, 0), (-8, -40, 0))         # backhand
    c["Attack3"] = swing(0.7, (190, 0, 10), (-10, 0, 5), (14, 0, 0), (-28, 0, 0))            # overhead
    c["Heavy"] = swing(1.0, (150, -80, 40), (10, 90, 0), (0, -55, 0), (-15, 60, 0))
    c["Block"] = (0.3, {ARM_L: [(0, (10, 0, -8)), (0.12, (75, 40, -20))], FORE_L: [(0, (30, 0, 0)), (0.12, (70, 0, 0))],
                        ARM_R: [(0, (25, 0, 8))], FORE_R: [(0, (35, 0, 0))], CHEST: [(0, I), (0.12, (-6, -18, 0))],
                        LEG_L: [(0, I), (0.12, (15, 0, 0))], SHIN_L: [(0, I), (0.12, (-20, 0, 0))]})
    tuck = (95, 0, 0)
    c["Roll"] = (0.55, {HIPS: [(0, I), (0.14, (-90, 0, 0)), (0.28, (-180, 0, 0)), (0.42, (-270, 0, 0)), (0.55, (-360, 0, 0))],
                        CHEST: [(0, I), (0.1, (-35, 0, 0)), (0.45, (-35, 0, 0)), (0.55, I)],
                        LEG_L: [(0, I), (0.1, tuck), (0.45, tuck), (0.55, I)], LEG_R: [(0, I), (0.1, tuck), (0.45, tuck), (0.55, I)],
                        SHIN_L: [(0, I), (0.1, (-110, 0, 0)), (0.45, (-110, 0, 0)), (0.55, I)],
                        SHIN_R: [(0, I), (0.1, (-110, 0, 0)), (0.45, (-110, 0, 0)), (0.55, I)],
                        ARM_L: [(0, (10, 0, -8)), (0.1, (60, 0, -10)), (0.55, (10, 0, -8))], ARM_R: [(0, (25, 0, 8)), (0.1, (60, 0, 10)), (0.55, (25, 0, 8))],
                        "move": [(0, (0, 0, 0)), (0.12, (0, -0.45, 0)), (0.42, (0, -0.45, 0)), (0.55, (0, 0, 0))]})
    c["Hit"] = (0.35, {CHEST: [(0, I), (0.08, (22, 12, 0)), (0.35, I)], HEAD: [(0, I), (0.08, (18, 0, 0)), (0.35, I)],
                       ARM_R: [(0, (25, 0, 8)), (0.08, (-20, 0, 35)), (0.35, (25, 0, 8))], ARM_L: [(0, (10, 0, -8)), (0.08, (-20, 0, -35)), (0.35, (10, 0, -8))],
                       "move": [(0, (0, 0, 0)), (0.08, (0, -0.04, 0.08)), (0.35, (0, 0, 0))]})
    c["Die"] = (1.1, {HIPS: [(0, I), (0.25, (25, 0, 0)), (0.7, (88, 0, 6)), (1.1, (90, 0, 6))],
                      CHEST: [(0, I), (0.25, (15, 0, 0)), (0.7, (-6, 0, 0))], HEAD: [(0, I), (0.7, (-12, 20, 0))],
                      ARM_R: [(0, (25, 0, 8)), (0.7, (-30, 0, 70))], ARM_L: [(0, (10, 0, -8)), (0.7, (-40, 0, -60))],
                      LEG_L: [(0, I), (0.3, (35, 0, 0)), (0.7, (10, 0, -8))], LEG_R: [(0, I), (0.7, (-5, 0, 10))],
                      SHIN_L: [(0, I), (0.3, (-50, 0, 0)), (0.7, (-12, 0, 0))],
                      "move": [(0, (0, 0, 0)), (0.25, (0, -0.1, 0.1)), (0.7, (0, -0.8, 0.5)), (1.1, (0, -0.82, 0.5))]})
    if style == "archer":
        aim = {ARM_L: [(0, (10, 0, -8)), (0.35, (88, 0, -6)), (0.9, (88, 0, -6)), (1.2, (10, 0, -8))], FORE_L: [(0, (30, 0, 0)), (0.35, (4, 0, 0)), (0.9, (4, 0, 0)), (1.2, (30, 0, 0))],
               ARM_R: [(0, (25, 0, 8)), (0.35, (85, -25, 10)), (0.8, (85, 10, 30)), (0.9, (80, 20, 40)), (1.2, (25, 0, 8))],
               FORE_R: [(0, (35, 0, 0)), (0.35, (60, 0, 0)), (0.8, (120, 0, 0)), (0.9, (40, 0, 0)), (1.2, (35, 0, 0))],
               CHEST: [(0, I), (0.35, (0, 12, 0)), (0.9, (0, 12, 0)), (1.2, I)]}
        c["Shoot"] = (1.2, aim)
    if style == "boss":
        c["Slam"] = swing(1.5, (200, 0, 20), (-20, 0, 5), (20, 0, 0), (-38, 0, 0))
        c["Sweep"] = swing(1.3, (110, -95, 40), (25, 110, 0), (0, -60, 0), (-10, 75, 0))
        c["Roar"] = (1.6, {CHEST: [(0, I), (0.4, (20, 0, 0)), (1.2, (20, 0, 0)), (1.6, I)], HEAD: [(0, I), (0.4, (25, 0, 0)), (1.2, (25, 0, 0)), (1.6, I)],
                           ARM_R: [(0, (25, 0, 8)), (0.4, (-20, 0, 75)), (1.2, (-20, 0, 75)), (1.6, (25, 0, 8))],
                           ARM_L: [(0, (10, 0, -8)), (0.4, (-20, 0, -75)), (1.2, (-20, 0, -75)), (1.6, (10, 0, -8))]})
        c["Kneel"] = (1.2, {HIPS: [(0, I), (0.6, (-12, 0, 0))], CHEST: [(0, I), (0.6, (-30, 0, 0))], HEAD: [(0, I), (0.6, (-35, 0, 0))],
                            LEG_L: [(0, I), (0.6, (80, 0, 0))], SHIN_L: [(0, I), (0.6, (-95, 0, 0))],
                            LEG_R: [(0, I), (0.6, (-5, 0, 0))], SHIN_R: [(0, I), (0.6, (-85, 0, 0))],
                            ARM_R: [(0, (25, 0, 8)), (0.6, (55, 0, 12))], FORE_R: [(0, (35, 0, 0)), (0.6, (10, 0, 0))],
                            "move": [(0, (0, 0, 0)), (0.6, (0, -0.42, 0))]})
    return c

PALETTES = {
    "knight": {"steel": (0.62, 0.66, 0.72), "steel_bright": (0.86, 0.89, 0.93), "gold": (0.85, 0.66, 0.25), "cloth": (0.12, 0.22, 0.62),
               "leather": (0.3, 0.2, 0.13), "dark": (0.22, 0.23, 0.27), "black": (0.03, 0.03, 0.04)},
    "boss": {"steel": (0.17, 0.16, 0.19), "steel_bright": (0.55, 0.2, 0.16), "gold": (0.75, 0.3, 0.12), "cloth": (0.45, 0.05, 0.05),
             "leather": (0.12, 0.08, 0.07), "dark": (0.08, 0.08, 0.1), "black": (0.9, 0.35, 0.1)},
    "bone": {"bone": (0.84, 0.8, 0.68), "rust": (0.45, 0.3, 0.2), "black": (0.04, 0.03, 0.03), "leather": (0.3, 0.2, 0.13),
             "wood": (0.38, 0.26, 0.15), "dark": (0.25, 0.25, 0.28)},
}

# ------------------------------------------------------------------ textures
def noise(size, cells, seed):
    """Tiling value noise in 0..1."""
    rng = np.random.default_rng(seed)
    g = rng.random((cells, cells))
    t = np.arange(size) * cells / size
    i, f = t.astype(int), t - t.astype(int)
    f = f * f * (3 - 2 * f)
    a, b = g[np.ix_(i % cells, i % cells)], g[np.ix_(i % cells, (i + 1) % cells)]
    c, d = g[np.ix_((i + 1) % cells, i % cells)], g[np.ix_((i + 1) % cells, (i + 1) % cells)]
    fx, fy = f[None, :], f[:, None]
    return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy

def fbm(size, seed, octaves=(4, 8, 16, 32, 64)):
    out = sum(noise(size, c, seed + k) / (2 ** k) for k, c in enumerate(octaves))
    return (out - out.min()) / (out.max() - out.min())

def save_texture(name, rgb):
    Image.fromarray((np.clip(rgb, 0, 1) * 255).astype(np.uint8), "RGB").save(os.path.join(OUT, name), optimize=True)

def bricks(size, rows, cols, seed, stagger=True):
    """Returns (mortar mask 0..1, a random value per brick)."""
    rng = np.random.default_rng(seed)
    y, x = np.mgrid[0:size, 0:size] / size
    row = np.floor(y * rows).astype(int)
    xs = x * cols + (row % 2) * 0.5 * stagger
    col = np.floor(xs).astype(int) % cols
    fy, fx = y * rows - row, xs - np.floor(xs)
    edge = np.minimum(np.minimum(fx, 1 - fx) * (rows / cols) * 2.2, np.minimum(fy, 1 - fy))
    mortar = np.clip(1 - edge / 0.07, 0, 1)
    return mortar, rng.random((rows, cols))[row, col]

def make_textures():
    S = 256
    grain = fbm(S, 1)
    fine = fbm(S, 7, (32, 64, 128))
    # castle wall: large grey blocks with dark joints and moss low in the grain
    mortar, tone = bricks(S, 6, 3, 2)
    v = 0.52 + (tone - 0.5) * 0.2 + (grain - 0.5) * 0.25 + (fine - 0.5) * 0.12
    stone = np.stack([v * 0.98, v * 0.97, v * 1.0], -1) * (1 - mortar[..., None] * 0.62)
    moss = np.clip((fbm(S, 11) - 0.62) * 5, 0, 1)[..., None]
    save_texture("tex_stone.png", stone * (1 - moss * 0.45) + np.array([0.2, 0.3, 0.14]) * moss * 0.45)
    # courtyard cobbles
    mortar, tone = bricks(S, 8, 8, 3)
    v = 0.44 + (tone - 0.5) * 0.3 + (fine - 0.5) * 0.18
    save_texture("tex_cobble.png", np.stack([v * 1.02, v * 0.98, v * 0.92], -1) * (1 - mortar[..., None] * 0.7))
    # hall floor: big dark flagstones
    mortar, tone = bricks(S, 4, 4, 5, stagger=False)
    v = 0.3 + (tone - 0.5) * 0.12 + (grain - 0.5) * 0.14
    save_texture("tex_flag.png", np.stack([v * 0.95, v * 0.95, v * 1.05], -1) * (1 - mortar[..., None] * 0.6))
    # grass with worn earth patches
    g = fbm(S, 21)
    blades = fbm(S, 23, (64, 128))
    earth = np.clip((fbm(S, 29, (3, 6, 12)) - 0.6) * 6, 0, 1)[..., None]
    green = np.stack([0.2 + g * 0.1, 0.34 + g * 0.16 + blades * 0.1, 0.13 + g * 0.05], -1)
    save_texture("tex_grass.png", green * (1 - earth) + np.array([0.33, 0.26, 0.18]) * (0.8 + blades[..., None] * 0.4) * earth)
    # planks
    y, x = np.mgrid[0:S, 0:S] / S
    plank = np.floor(x * 4)
    streak = fbm(S, 31, (2, 4, 8))[:, (np.arange(S) * 7) % S]
    rings = 0.5 + 0.5 * np.sin((y * 40 + streak * 14 + plank * 5))
    gap = np.clip(1 - np.minimum(x * 4 - plank, 1 - (x * 4 - plank)) / 0.04, 0, 1)
    v = 0.42 + rings * 0.1 + (np.random.default_rng(4).random(4)[plank.astype(int)] - 0.5) * 0.12
    save_texture("tex_wood.png", np.stack([v * 1.1, v * 0.78, v * 0.5], -1) * (1 - gap[..., None] * 0.7))
    # roof tiles
    mortar, tone = bricks(S, 8, 6, 9)
    v = 0.4 + (tone - 0.5) * 0.25 + (fine - 0.5) * 0.1
    save_texture("tex_roof.png", np.stack([v * 1.25, v * 0.6, v * 0.45], -1) * (1 - mortar[..., None] * 0.55))

# ------------------------------------------------------------------ scenery
MAT = {"stone": ((1, 1, 1), "tex_stone.png"), "cobble": ((1, 1, 1), "tex_cobble.png"), "flag": ((1, 1, 1), "tex_flag.png"),
       "grass": ((1, 1, 1), "tex_grass.png"), "wood": ((1, 1, 1), "tex_wood.png"), "roof": ((1, 1, 1), "tex_roof.png"),
       "iron": ((0.16, 0.16, 0.18), None), "cloth": ((0.55, 0.08, 0.08), None), "gold": ((0.85, 0.66, 0.25), None),
       "leaf": ((0.13, 0.27, 0.15), None), "bark": ((0.27, 0.19, 0.13), None), "rock": ((0.42, 0.42, 0.45), None),
       "glass": ((0.75, 0.1, 0.12), None), "glow": ((0.5, 0.85, 1.0), None)}

def wall(length, height=6.0, thick=1.6, crenels=True):
    m = Mesh()
    m.box("stone", (0, height / 2, 0), (length, height, thick))
    if crenels:
        m.box("stone", (0, height + 0.15, 0), (length + 0.3, 0.3, thick + 0.3))       # walkway lip
        n = max(int(length // 2), 1)
        for i in range(n):
            x = -length / 2 + (i + 0.5) * length / n
            for z in (-thick / 2 - 0.02, thick / 2 + 0.02):
                m.box("stone", (x, height + 0.75, z), (length / n * 0.55, 0.9, 0.35))
    return m

def tower():
    m = Mesh()
    m.lathe("stone", [(0, 3.4), (1.0, 3.1), (11, 3.0), (11.4, 3.5), (12, 3.5)], sides=12, flat=True)
    for k in range(12):
        a = (k + 0.5) / 12 * math.tau
        if k % 2 == 0:
            m.box("stone", (math.cos(a) * 3.3, 12.5, math.sin(a) * 3.3), (0.5, 1.0, 1.3), r=(0, -math.degrees(a), 0))
    m.lathe("roof", [(12, 2.9), (16.5, 0.0)], sides=12, flat=True)
    m.lathe("gold", [(16.4, 0.06), (17.6, 0.02)], sides=5)
    m.box("cloth", (0.45, 17.2, 0), (0.9, 0.5, 0.03))
    return m

def pillar():
    m = Mesh()
    m.box("stone", (0, 0.25, 0), (1.5, 0.5, 1.5))
    m.lathe("stone", [(0.5, 0.6), (0.7, 0.5), (6.3, 0.45), (6.5, 0.62)], sides=10)
    m.box("stone", (0, 6.75, 0), (1.6, 0.5, 1.6))
    return m

def portcullis():
    m = Mesh()
    for i in range(7):
        m.box("iron", (-2.4 + i * 0.8, 2.6, 0), (0.14, 5.2, 0.14))
        m.lathe("iron", [(-0.25, 0.0), (0.0, 0.1)], center=(-2.4 + i * 0.8, 0), sides=4)
    for y in (0.8, 2.0, 3.2, 4.4):
        m.box("iron", (0, y, 0), (5.4, 0.12, 0.1))
    m.box("wood", (0, 5.3, 0), (5.6, 0.35, 0.3))
    return m

def torch():
    m = Mesh()
    m.lathe("iron", [(0, 0.22), (0.08, 0.2), (0.12, 0.05), (1.9, 0.045), (2.0, 0.16), (2.25, 0.24)], sides=8)
    return m

def barrel():
    m = Mesh()
    m.lathe("wood", [(0, 0.36), (0.3, 0.44), (0.7, 0.44), (1.0, 0.36)], sides=12)
    for y in (0.16, 0.5, 0.84):
        m.lathe("iron", [(y - 0.03, 0.455 - abs(y - 0.5) * 0.14), (y + 0.03, 0.455 - abs(y - 0.5) * 0.14)], sides=12)
    return m

def crate():
    m = Mesh()
    m.box("wood", (0, 0.5, 0), (1, 1, 1))
    for x in (-0.46, 0.46):
        for z in (-0.46, 0.46):
            m.box("bark", (x, 0.5, z), (0.1, 1.04, 0.1))
    return m

def pine():
    m = Mesh()
    m.lathe("bark", [(0, 0.3), (2.2, 0.2)], sides=7)
    for y, r, h in ((1.4, 2.0, 2.6), (3.0, 1.55, 2.3), (4.5, 1.05, 2.1)):
        m.lathe("leaf", [(y, r), (y + h, 0.0)], sides=9, flat=True)
    return m

def rock():
    m = Mesh()
    prof = [(0, 1.0), (0.5, 1.25), (1.1, 1.0), (1.5, 0.5), (1.65, 0.0)]
    m.lathe("rock", prof, sides=7, sx=1.2, sz=0.9, flat=True)
    for vs in m.tris.values():
        for p, _, _ in vs:
            p += np.sin(p * 9.1) * 0.08
    return m

def banner():
    m = Mesh()
    m.lathe("wood", [(0, 0.07), (5.0, 0.05)], sides=6)
    m.box("wood", (0.6, 4.8, 0), (1.5, 0.08, 0.08))
    m.box("cloth", (0.65, 3.6, 0), (1.1, 2.3, 0.03))
    m.box("gold", (0.65, 3.8, 0.02), (0.4, 0.6, 0.02))
    return m

def shrine():
    m = Mesh()
    m.lathe("stone", [(0, 1.1), (0.25, 1.0), (0.3, 0.7), (1.0, 0.55), (1.1, 0.8), (1.25, 0.8)], sides=8, flat=True)
    m.lathe("glow", [(1.35, 0.0), (1.75, 0.28), (2.4, 0.0)], sides=6, flat=True)
    return m

def potion():
    m = Mesh()
    m.lathe("glass", [(0, 0.0), (0.02, 0.14), (0.2, 0.16), (0.3, 0.06), (0.4, 0.05)], sides=8)
    m.lathe("wood", [(0.4, 0.06), (0.47, 0.05)], sides=6)
    return m

def slab(mat, w, d):
    m = Mesh()
    m.box(mat, (0, -0.5, 0), (w, 1.0, d))
    return m

def throne():
    m = Mesh()
    m.box("stone", (0, 0.3, 0), (3.2, 0.6, 2.6))
    m.box("stone", (0, 0.95, 0.1), (1.5, 0.7, 1.3))
    m.box("stone", (0, 2.6, 0.75), (1.7, 4.0, 0.35))
    for x in (-0.85, 0.85):
        m.box("stone", (x, 1.5, 0.1), (0.25, 0.5, 1.3))
        m.lathe("gold", [(4.5, 0.12), (5.2, 0.0)], center=(x * 0.9, 0.75), sides=5)
    m.box("cloth", (0, 2.6, 0.55), (1.1, 3.4, 0.05))
    return m

if __name__ == "__main__":
    make_textures()
    for name, mesh in (("wall_12", wall(12)), ("wall_6", wall(6)), ("wall_hall", wall(12, 8.0, 1.2, False)),
                       ("pier", wall(3.5, 8.0, 3.2)), ("lintel", wall(6.0, 2.6, 3.2)), ("tower", tower()), ("pillar", pillar()),
                       ("portcullis", portcullis()), ("torch", torch()), ("barrel", barrel()), ("crate", crate()),
                       ("pine", pine()), ("rock", rock()), ("banner", banner()), ("shrine", shrine()), ("potion", potion()),
                       ("throne", throne()), ("ground_grass", slab("grass", 80, 56)), ("ground_cobble", slab("cobble", 36, 36)),
                       ("ground_hall", slab("flag", 26, 34)), ("roof_hall", slab("wood", 28, 36))):
        write_obj(name, mesh, MAT, tile=3.0 if name.startswith("ground") else 2.5)
    for style, palette in (("knight", "knight"), ("boss", "boss"), ("skeleton", "bone"), ("archer", "bone"), ("brute", "bone")):
        write_gltf(style, humanoid(style), PALETTES[palette], JOINTS, clips_for(style))
    # the list of files the editor embeds
    files = sorted(f for f in os.listdir(OUT))
    rs = "// Generated by tools/make_ashen_assets.py. Do not edit.\npub const FILES: &[(&str, &[u8])] = &[\n"
    rs += "".join(f'    ("{f}", include_bytes!("../template/ashen/{f}")),\n' for f in files) + "];\n"
    open(os.path.join(OUT, "..", "..", "src", "ashen_files.rs"), "w").write(rs)
    total = sum(os.path.getsize(os.path.join(OUT, f)) for f in os.listdir(OUT))
    print(f"{len(os.listdir(OUT))} files, {total / 1024:.0f} KB in {os.path.normpath(OUT)}")
